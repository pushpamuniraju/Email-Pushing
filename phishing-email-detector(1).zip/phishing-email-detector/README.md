# Phishing Email Detector

## Run
1. Install Python.
2. Open terminal in this folder.
3. Run:
   pip install -r requirements.txt
4. Train the model:
   python train_model.py
5. Start website:
   python app.py
6. Open http://127.0.0.1:5000

This is an educational demo. The included dataset is small; replace dataset.csv with a larger labeled dataset for meaningful accuracy.
