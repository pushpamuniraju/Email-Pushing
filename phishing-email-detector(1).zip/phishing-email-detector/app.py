from flask import Flask, render_template, request, jsonify
import joblib
import re

app = Flask(__name__)

model = joblib.load("phishing_model.pkl")

def has_url(text):
    return 1 if re.search(r'https?://|www\.', text, re.I) else 0

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    email = request.form.get("email", "").strip()
    if not email:
        return jsonify({"error": "Please enter an email."})

    prediction = model.predict([email])[0]
    probability = max(model.predict_proba([email])[0]) * 100

    result = "PHISHING" if prediction == 1 else "SAFE"
    return jsonify({
        "result": result,
        "confidence": round(probability, 2),
        "url_found": bool(has_url(email))
    })

if __name__ == "__main__":
    app.run(debug=True)
