import pandas as pd
import joblib
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

# dataset.csv contains: text,label
df = pd.read_csv("dataset.csv")
df["text"] = df["text"].fillna("")

model = Pipeline([
    ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1,2))),
    ("classifier", LogisticRegression(max_iter=1000))
])

model.fit(df["text"], df["label"])
joblib.dump(model, "phishing_model.pkl")
print("Model trained and saved as phishing_model.pkl")
